var searchData=
[
  ['getdata',['getData',['../awsinfo_8c.html#a0cc5b988b9039e54e9dfbd823a715056',1,'awsinfo.c']]],
  ['getday',['getDay',['../awsinfo_8c.html#ab44879025a5f4f6683a4024b6a20a5f7',1,'awsinfo.c']]],
  ['getmonth',['getMonth',['../awsinfo_8c.html#a94d4185170a19084d48c36dbb442167b',1,'awsinfo.c']]],
  ['gettime',['getTime',['../server_info_8c.html#a81a0d93ad8512065af8f98914ed36b45',1,'serverInfo.c']]],
  ['getyear',['getYear',['../awsinfo_8c.html#a8f4a86ff3884dbd3f947b4f6c0c08b7f',1,'awsinfo.c']]]
];
