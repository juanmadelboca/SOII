var searchData=
[
  ['search',['search',['../server_info_8c.html#a7cea4d3469242a87f3d47921ac2cf074',1,'serverInfo.c']]],
  ['serverdata',['serverData',['../structserver_data.html',1,'']]],
  ['serverinfo_2ec',['serverInfo.c',['../server_info_8c.html',1,'']]],
  ['setweb',['setWeb',['../delete_8c.html#a6cebf3fe46e1184401f38a81598d56a1',1,'setWeb():&#160;delete.c'],['../server_info_8c.html#a9e601c71e938f7e5bf1a0cb046503e3f',1,'setWeb(struct serverData *srv):&#160;serverInfo.c'],['../upload_8c.html#a6cebf3fe46e1184401f38a81598d56a1',1,'setWeb():&#160;upload.c']]]
];
