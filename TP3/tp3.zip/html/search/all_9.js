var searchData=
[
  ['upload_2ec',['upload.c',['../upload_8c.html',1,'']]],
  ['uptime',['uptime',['../structserver_data.html#a26d9bdc16e7cacee5aa7c9de240f6abc',1,'serverData::uptime()'],['../server_info_8c.html#a7c8afa1d5d297bf5e8196d34ee0e2f8e',1,'upTime():&#160;serverInfo.c']]]
];
