var searchData=
[
  ['serverdata',['serverData',['../structserver_data.html',1,'']]]
];
