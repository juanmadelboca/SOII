var searchData=
[
  ['awsinfo_2ec',['awsinfo.c',['../awsinfo_8c.html',1,'']]]
];
