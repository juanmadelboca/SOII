var searchData=
[
  ['delete_2ec',['delete.c',['../delete_8c.html',1,'']]]
];
