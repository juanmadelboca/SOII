var searchData=
[
  ['serverinfo_2ec',['serverInfo.c',['../server_info_8c.html',1,'']]]
];
