var searchData=
[
  ['uptime',['upTime',['../server_info_8c.html#a7c8afa1d5d297bf5e8196d34ee0e2f8e',1,'serverInfo.c']]]
];
