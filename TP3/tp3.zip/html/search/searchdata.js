var indexSectionsWithContent =
{
  0: "acdfglmpsu",
  1: "s",
  2: "admsu",
  3: "acdglmpsu",
  4: "cdfmu"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables"
};

var indexSectionLabels =
{
  0: "All",
  1: "Data Structures",
  2: "Files",
  3: "Functions",
  4: "Variables"
};

