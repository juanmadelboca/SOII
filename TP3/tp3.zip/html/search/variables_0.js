var searchData=
[
  ['cpumodel',['cpuModel',['../structserver_data.html#aa0dcd9b233a31d90de75e4072de95cca',1,'serverData']]],
  ['cputype',['cpuType',['../structserver_data.html#a8f88ecb6bd38ff3fdea1a9270dad5c9b',1,'serverData']]]
];
