var searchData=
[
  ['date',['date',['../structserver_data.html#a4373f53bb18f843a0ddece9a1013449d',1,'serverData']]]
];
