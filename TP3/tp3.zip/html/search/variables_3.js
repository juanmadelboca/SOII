var searchData=
[
  ['memoryfree',['memoryFree',['../structserver_data.html#ad1bba3e10658f8e7b0b7051c554b4f53',1,'serverData']]],
  ['memorytotal',['memoryTotal',['../structserver_data.html#ac1442751817edc8e5bee4195eb081a54',1,'serverData']]]
];
