var searchData=
[
  ['uptime',['uptime',['../structserver_data.html#a26d9bdc16e7cacee5aa7c9de240f6abc',1,'serverData']]]
];
